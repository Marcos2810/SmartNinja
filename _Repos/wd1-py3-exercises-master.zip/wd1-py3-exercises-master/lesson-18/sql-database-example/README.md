### Heroku add-ons

If you'll deploy this web app to Heroku, make sure to have the following add-ons enabled:

- Heroku Postgres
- Adminium

