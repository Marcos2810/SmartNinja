import random
from datetime import datetime

random_num = random.randint(1, 50)
print(random_num)

time_now = datetime.now()
print(time_now)
