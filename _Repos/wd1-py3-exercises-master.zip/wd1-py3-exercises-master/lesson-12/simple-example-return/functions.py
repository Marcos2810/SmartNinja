def say_hello(name):
    return "Hello {}!".format(name)
