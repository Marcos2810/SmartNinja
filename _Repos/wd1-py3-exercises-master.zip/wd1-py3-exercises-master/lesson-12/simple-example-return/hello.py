from functions import say_hello

text = say_hello(name="Ninja")
print(text)
