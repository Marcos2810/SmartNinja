from functions import say_hello

say_hello(name="Ninja")
