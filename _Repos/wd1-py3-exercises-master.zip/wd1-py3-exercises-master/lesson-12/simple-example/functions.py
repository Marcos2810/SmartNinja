def say_hello(name):
    print("Hello {}!".format(name))
