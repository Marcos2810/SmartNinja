whole_num = 22  # integer

decimal_num = 3.14  # float: number with a decimal point

some_string = "Hello, SmartNinja"  # a string of characters

some_bool = True  # boolean: either True or False
