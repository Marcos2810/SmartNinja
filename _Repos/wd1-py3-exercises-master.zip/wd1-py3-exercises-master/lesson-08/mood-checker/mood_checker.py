mood = input("What is your mood today? ")

if mood == "happy":
    print("It is great to see you happy!")
elif mood == "nervous":
    print("Take a deep breath 3 times.")
elif mood == "sad":
    print("Cheer up, mate!")
elif mood == "excited":
    print("Woohoo!")
elif mood == "relaxed":
    print("Yeah, today is the day to chill...")
else:
    print("I don't recognize this mood.")
